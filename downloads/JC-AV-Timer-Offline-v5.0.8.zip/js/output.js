(() => {
  const $=id=>document.getElementById(id);
  const timer=$('outputTimer'),paused=$('outputPaused'),finished=$('outputFinished'),progress=$('outputProgress'),bar=$('outputProgressBar'),banner=$('outputBanner'),bannerText=$('outputBannerText');
  const fullscreenBtn=$('outputFullscreenBtn'),fullscreenHotspot=$('fullscreenHotspot');
  const preview=new URLSearchParams(location.search).get('preview')==='1';
  let latestPayload=null;
  let receivedAt=performance.now();

  function mixHex(base,target,amount){const clean=v=>String(v||'').replace('#','').trim();const a=clean(base),b=clean(target);if(!/^[0-9a-fA-F]{6}$/.test(a)||!/^[0-9a-fA-F]{6}$/.test(b))return base||'#000000';const out=[];for(let i=0;i<3;i++){const av=parseInt(a.slice(i*2,i*2+2),16),bv=parseInt(b.slice(i*2,i*2+2),16);out.push(Math.round(av+(bv-av)*amount).toString(16).padStart(2,'0'))}return `#${out.join('')}`}
  function sameHueGradient(base){return{light:mixHex(base,'#ffffff',.22),dark:mixHex(base,'#000000',.34)}}
  function formatTime(seconds){let total=Math.round(Number(seconds)||0);const neg=total<0;total=Math.abs(total);const h=Math.floor(total/3600),m=Math.floor((total%3600)/60),s=total%60;const body=h>0?`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;return neg?`-${body}`:body}
  function liveState(payload){const source=payload?.state||{};const s={...source};let seconds=Number(s.seconds||0);if(s.running&&!s.paused&&Number(s.clockAnchorMs)>0){const delta=Math.max(0,(Date.now()-Number(s.clockAnchorMs))/1000);if(s.countUp)seconds=Math.max(0,Number(s.anchorElapsed||0)+delta);else seconds=Number(s.anchorRemaining||0)-delta}s.seconds=seconds;s.formatted=formatTime(seconds);s.displayTime=s.formatted;s.finished=!s.countUp&&seconds<=0&&Number(s.duration)>0;const duration=Math.max(0,Number(s.duration||0));s.progressPercent=duration>0?(s.countUp?Math.min(100,seconds/duration*100):Math.max(0,Math.min(100,seconds/duration*100))):0;return s}

  document.body.classList.toggle('preview-mode',preview);
  function updateFullscreenButton(){if(fullscreenBtn){fullscreenBtn.textContent=document.fullscreenElement?'Exit Fullscreen':'Fullscreen';fullscreenBtn.setAttribute('aria-label',fullscreenBtn.textContent)}}
  async function toggleFullscreen(){try{if(document.fullscreenElement)await document.exitFullscreen?.();else await document.documentElement.requestFullscreen?.()}catch(err){console.warn('Fullscreen request failed',err)}updateFullscreenButton()}
  if(preview&&fullscreenHotspot)fullscreenHotspot.classList.add('hidden');fullscreenBtn?.addEventListener('click',toggleFullscreen);document.addEventListener('fullscreenchange',updateFullscreenButton);updateFullscreenButton();

  function applyCustomFont(display){const family=String(display.fontFamily||'Inter');document.documentElement.style.setProperty('--out-font',JSON.stringify(family));document.documentElement.style.setProperty('--out-weight',String(display.fontWeight||'900'))}
  function apply(payload){
    if(!payload)return;latestPayload=payload;const display=payload.display||{},state=liveState(payload);const baseBg=display.bg||'#00324b',gradient=sameHueGradient(baseBg);
    document.documentElement.style.setProperty('--out-bg',baseBg);document.documentElement.style.setProperty('--out-bg-light',gradient.light);document.documentElement.style.setProperty('--out-bg-dark',gradient.dark);document.documentElement.style.setProperty('--out-timer',display.fg||'#f5f5f5');document.documentElement.style.setProperty('--out-progress',display.progress||'#ff4b4b');document.documentElement.style.setProperty('--out-time',display.timeColor||'#ff3030');document.documentElement.style.setProperty('--out-scale',Number(display.scale||1));document.documentElement.style.setProperty('--out-chroma',display.chromaColor||'#00ff00');document.documentElement.style.setProperty('--active-warning',state.warningColor||display.timeColor||'#ff3030');applyCustomFont(display);
    document.body.classList.toggle('light-output',!!display.light&&!display.chroma);document.body.classList.toggle('chroma-output',!!display.chroma);document.body.classList.toggle('chroma-invert',!!display.chromaInvert);document.body.classList.toggle('flat-output',display.gradient===false||!!display.chroma);document.body.classList.toggle('shadow-output',display.shadow!==false&&!display.chroma);
    const showingClock=(state.displayMode||display.displayMode)==='clock',clockFormat=String(state.clockFormat||display.clockFormat||'24')==='12'?'12':'24';
    document.body.classList.toggle('clock-output',showingClock);document.body.classList.toggle('clock-12-output',showingClock&&clockFormat==='12');
    const clockNow=Number(payload.sentAt||Date.now())+Math.max(0,performance.now()-receivedAt);
    const wallTime=window.JCClock?.format(clockNow,clockFormat,state.clockTimeZone||display.clockTimeZone||'UTC')||state.clockTime||'00:00:00';
    const overtime=!state.countUp&&Number(state.seconds)<=0&&Number(state.duration)>0;timer.textContent=showingClock?wallTime:(state.formatted||'00:00');timer.dataset.text=timer.textContent;timer.classList.toggle('warning',!showingClock&&!!state.warningActive&&!overtime);timer.classList.toggle('overtime',!showingClock&&overtime);timer.classList.toggle('flash',!showingClock&&!!state.flashTimer);paused.classList.toggle('hidden',showingClock||!state.paused);finished.classList.toggle('hidden',showingClock||!overtime);
    const showProgress=!showingClock&&!!display.showProgress;progress.classList.toggle('hidden',!showProgress);progress.classList.toggle('overtime',overtime);bar.style.width=`${Math.max(0,Math.min(100,Number(state.progressPercent)||0))}%`;
    const showBanner=!!state.bannerVisible&&!!String(state.bannerText||'').trim();bannerText.textContent=state.bannerText||'';banner.classList.toggle('hidden',!showBanner);banner.classList.toggle('warning',state.bannerKind==='warning');banner.classList.toggle('flash',!!state.flashMessage&&showBanner);if(state.bannerKind==='warning'&&state.warningColor)document.documentElement.style.setProperty('--active-warning',state.warningColor);
  }
  window.AVSync.onState(payload=>{receivedAt=performance.now();apply(payload)},true);window.AVSync.requestState();setInterval(()=>{if(latestPayload)apply(latestPayload)},250);window.addEventListener('focus',()=>{if(latestPayload)apply(latestPayload)});document.addEventListener('visibilitychange',()=>{if(!document.hidden&&latestPayload)apply(latestPayload)});
})();
