JC AV Timer v5.0.8 - Clock mode

Open "JC AV Timer.html" on a desktop computer.
The Timer / Clock switch is above the large time readout.
Clock mode supports 24 hour (HH:MM:SS) and 12 hour (HH:MM:SS AM/PM), with live seconds.
Your countdown continues behind the clock.
The clock uses the operating computer time and timezone.
Companion needs the local timer webpage and port 3210.
Internet Remote Viewer still requires an internet connection.
