const DEFAULT_VALUES = {
  display_time:'00:00', remaining:'00:00', hours:'00', minutes:'00', seconds_part:'00', seconds:0, duration:0,
  status:'READY', pause_resume_label:'PAUSE', connection_status:'OFFLINE', running:'no', paused:'no', warning:'no', warning_label:'', warning_remaining:0,
  queue_length:0, queue_enabled:'no', warnings_enabled:'yes', progress_enabled:'no', gradient_enabled:'yes', minimal_enabled:'no',
  chroma_enabled:'no', light_enabled:'no', auto_next:'no', autostart:'yes', count_up:'no', output_size:100,
  bridge_online:'no', browser_online:'no'
}

module.exports = function(self) {
  // Store defaults BEFORE definitions are registered. The self-contained build
  // can send these in the same IPC packet as the definitions, preventing $NA
  // while Companion is still initialising the connection.
  self.variableDefaults = { ...DEFAULT_VALUES }

  self.setVariableDefinitions([
    { variableId:'display_time', name:'Exact timer display text' },
    { variableId:'remaining', name:'Timer display text (legacy)' },
    { variableId:'hours', name:'Displayed hours (HH)' },
    { variableId:'minutes', name:'Displayed minutes component (MM)' },
    { variableId:'seconds_part', name:'Displayed seconds component (SS)' },
    { variableId:'seconds', name:'Displayed total seconds' },
    { variableId:'duration', name:'Timer duration seconds' },
    { variableId:'status', name:'Timer status (READY / ARMED / RUNNING / PAUSED / TIME)' },
    { variableId:'pause_resume_label', name:'Dynamic Pause / Resume label' },
    { variableId:'connection_status', name:'Timer connection status (CONNECTED / OFFLINE)' },
    { variableId:'running', name:'Running (yes/no)' },
    { variableId:'paused', name:'Paused (yes/no)' },
    { variableId:'warning', name:'Custom warning active (yes/no)' },
    { variableId:'warning_label', name:'Active custom warning label' },
    { variableId:'warning_remaining', name:'Seconds remaining for warning evaluation' },
    { variableId:'queue_length', name:'Queued timer count' },
    { variableId:'queue_enabled', name:'Queue enabled (yes/no)' },
    { variableId:'warnings_enabled', name:'Warnings enabled (yes/no)' },
    { variableId:'progress_enabled', name:'Progress bar enabled (yes/no)' },
    { variableId:'gradient_enabled', name:'Gradient enabled (yes/no)' },
    { variableId:'minimal_enabled', name:'Minimal mode enabled (yes/no)' },
    { variableId:'chroma_enabled', name:'Chroma mode enabled (yes/no)' },
    { variableId:'light_enabled', name:'Light output enabled (yes/no)' },
    { variableId:'auto_next', name:'Queue auto-next enabled (yes/no)' },
    { variableId:'autostart', name:'Auto start enabled (yes/no)' },
    { variableId:'count_up', name:'Count up enabled (yes/no)' },
    { variableId:'output_size', name:'Output timer size percent' },
    { variableId:'bridge_online', name:'Timer browser connected (yes/no, legacy id)' },
    { variableId:'browser_online', name:'GitHub / app timer connected (yes/no)' }
  ])

  self.setVariableValues(DEFAULT_VALUES)
}

module.exports.DEFAULT_VALUES = DEFAULT_VALUES
