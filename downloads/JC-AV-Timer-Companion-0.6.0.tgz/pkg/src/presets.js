const { combineRgb } = require('../shim')
const WHITE=combineRgb(255,255,255), GREY=combineRgb(48,55,66), GREEN=combineRgb(20,135,68), AMBER=combineRgb(170,105,0), RED=combineRgb(170,35,45), BLUE=combineRgb(20,90,160), DARK=combineRgb(24,28,35), CYAN=combineRgb(0,115,145), PURPLE=combineRgb(100,60,155)

const TIMES=[['1m',60],['2m',120],['5m',300],['10m',600],['15m',900],['20m',1200],['30m',1800],['45m',2700],['60m',3600]]

const button=(category,name,text,bg,actionId=null,options={},feedbacks=[],size='11')=>({
  type:'button', category, name,
  style:{text,size:String(size),color:WHITE,bgcolor:bg},
  steps:[{down:actionId?[{actionId,options}]:[],up:[]}],
  feedbacks
})

const live=(p,id,name,label,mode,size='14')=>{
  p[id]=button('JC · Control',name,label,DARK,null,{},[
    {feedbackId:'display_value',options:{mode},style:{}}
  ],size)
}

const toggle=(p,id,label,feature,color=BLUE)=>{
  p[id]=button('JC · Control',`${label} Toggle`,label,GREY,'feature',{feature},[
    {feedbackId:'feature_state',options:{feature,label},style:{}}
  ],'9')
}

module.exports = function(self) {
  const p={}

  // CONTROL: live displays, status, transport, feature toggles and output size.
  // The base text is intentionally static so the preset browser never shows $NA.
  // Advanced feedback replaces it with live values after the preset is placed.
  live(p,'live_time_small','Live Timer · Small','TIMER','time','12')
  live(p,'live_time_medium','Live Timer · Medium','TIMER','time','18')
  live(p,'live_time_large','Live Timer · Large','TIMER','time','28')
  live(p,'hh','Hours HH','HH','hh','26')
  live(p,'mm','Minutes MM','MM','mm','26')
  live(p,'ss','Seconds SS','SS','ss','26')
  live(p,'status','Timer Status','STATUS','status','12')
  live(p,'connection','Timer Connection','CONNECTED','connection','11')
  live(p,'queue_count','Queue Count','QUEUE','queue','11')
  live(p,'warning_label','Warning Label','WARNING','warning','11')

  p.running_status=button('JC · Control','Running Feedback','RUNNING',DARK,null,{},[{feedbackId:'running',options:{},style:{bgcolor:GREEN,color:WHITE}}],'11')
  p.paused_status=button('JC · Control','Paused Feedback','PAUSED',DARK,null,{},[{feedbackId:'paused',options:{},style:{bgcolor:AMBER,color:WHITE}}],'11')
  p.time_status=button('JC · Control','TIME Feedback','TIME',DARK,null,{},[{feedbackId:'finished',options:{},style:{bgcolor:RED,color:WHITE}}],'14')

  p.start=button('JC · Control','Start / Resume','START',GREEN,'start',{},[],'13')
  p.pause_resume=button('JC · Control','Pause / Resume Toggle','PAUSE',GREY,'toggle',{},[{feedbackId:'pause_resume_state',options:{},style:{}}],'12')
  p.reset=button('JC · Control','Reset','RESET',BLUE,'reset',{},[],'12')
  p.stop=button('JC · Control','Stop / Clear','STOP',RED,'stop',{},[],'12')

  toggle(p,'warnings_toggle','WARNINGS','warnings',AMBER)
  toggle(p,'progress_toggle','PROGRESS','progress',CYAN)
  toggle(p,'gradient_toggle','GRADIENT','gradient',BLUE)
  toggle(p,'minimal_toggle','MINIMAL','minimal',PURPLE)
  toggle(p,'chroma_toggle','CHROMA','chroma',GREEN)
  toggle(p,'light_toggle','LIGHT','light',BLUE)
  toggle(p,'count_up_toggle','COUNT UP','count_up',PURPLE)
  toggle(p,'autostart_toggle','AUTO START','autostart',GREEN)

  const sizes=[['Small',0.75],['Medium',1],['Large',1.25],['XL',1.5],['XXL',1.8]]
  for(const [label,scale] of sizes){
    p[`size_${String(scale).replace('.','_')}`]=button('JC · Control',`Timer Size ${label}`,`SIZE\n${label.toUpperCase()}`,BLUE,'output_size',{scale},[],'10')
  }

  for(const [label,seconds] of TIMES){
    p[`add_${seconds}`]=button('JC · Add',`Add ${label}`,`+${label}`,GREEN,'add_preset',{seconds},[],'14')
    p[`sub_${seconds}`]=button('JC · Remove',`Remove ${label}`,`−${label}`,RED,'subtract_preset',{seconds},[],'14')
    p[`start_${seconds}`]=button('JC · Start',`Start ${label}`,`START\n${label}`,GREEN,'start_preset',{seconds},[],'11')
    p[`set_${seconds}`]=button('JC · Set',`Set ${label}`,`SET\n${label}`,GREY,'set_preset',{seconds},[],'11')
  }

  p.queue_toggle=button('JC · Queue','Queue Toggle','QUEUE',GREY,'feature',{feature:'queue'},[{feedbackId:'feature_state',options:{feature:'queue',label:'QUEUE'},style:{}}],'9')
  p.auto_next_toggle=button('JC · Queue','Auto Next Toggle','AUTO NEXT',GREY,'feature',{feature:'auto_next'},[{feedbackId:'feature_state',options:{feature:'auto_next',label:'AUTO NEXT'},style:{}}],'9')
  p.queue_start=button('JC · Queue','Start Queue','START\nQUEUE',GREEN,'queue_start',{},[],'10')
  p.queue_next=button('JC · Queue','Next Queue Timer','NEXT',BLUE,'next',{},[],'12')
  p.queue_remove_last=button('JC · Queue','Remove Last Queue Timer','REMOVE\nLAST',AMBER,'queue_remove_last',{},[],'10')
  p.queue_clear=button('JC · Queue','Clear Queue','CLEAR\nQUEUE',RED,'queue_clear',{},[],'10')

  for(const [label,seconds] of TIMES){
    p[`queue_add_${seconds}`]=button('JC · Queue Add',`Queue + ${label}`,`QUEUE +\n${label}`,GREEN,'queue_add_preset',{seconds},[],'10')
  }

  self.setPresetDefinitions(p)
}
