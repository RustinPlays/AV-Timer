const { combineRgb } = require('../shim')
const WHITE=combineRgb(255,255,255), GREY=combineRgb(48,55,66), GREEN=combineRgb(20,150,75), AMBER=combineRgb(190,120,0), RED=combineRgb(190,30,40), BLUE=combineRgb(20,90,160), CYAN=combineRgb(0,120,150), PURPLE=combineRgb(105,65,160), DARK=combineRgb(24,28,35)

const FEATURE_META = {
  queue:      {state:'queueEnabled',     color:BLUE},
  warnings:   {state:'warningsEnabled',  color:AMBER},
  progress:   {state:'progressEnabled',  color:CYAN},
  gradient:   {state:'gradientEnabled',  color:BLUE, defaultOn:true},
  minimal:    {state:'minimalEnabled',   color:PURPLE},
  chroma:     {state:'chromaEnabled',    color:GREEN},
  light:      {state:'lightEnabled',     color:BLUE},
  auto_next:  {state:'autoNext',         color:BLUE},
  autostart:  {state:'autostart',        color:GREEN, defaultOn:true},
  count_up:   {state:'countUp',          color:PURPLE}
}

function featureOn(self, feature){
  const meta=FEATURE_META[feature]
  if(!meta) return false
  const v=self.getLiveState?.()?.[meta.state] ?? self.state?.[meta.state]
  return v === undefined ? !!meta.defaultOn : !!v
}

function timerBg(self){
  const s=self.getLiveState?.()||self.state||{}
  if(s.finished) return RED
  if(s.warningActive) return AMBER
  if(s.paused) return AMBER
  if(s.running) return GREEN
  return DARK
}

module.exports = function(self) {
  self.setFeedbackDefinitions({
    bridge_online:{type:'boolean',name:'Timer browser connected (legacy id)',defaultStyle:{bgcolor:BLUE,color:WHITE},options:[],callback:()=>!!self.browserOnline},
    browser_online:{type:'boolean',name:'GitHub / app timer is connected',defaultStyle:{bgcolor:GREEN,color:WHITE},options:[],callback:()=>!!self.browserOnline},
    running:{type:'boolean',name:'Timer is running',defaultStyle:{bgcolor:GREEN,color:WHITE},options:[],callback:()=>{const s=self.getLiveState?.()||self.state||{};return !!s.running&&!s.paused}},
    paused:{type:'boolean',name:'Timer is paused',defaultStyle:{bgcolor:AMBER,color:WHITE},options:[],callback:()=>!!(self.getLiveState?.()||self.state||{}).paused},
    warning_active:{type:'boolean',name:'Custom warning is active',defaultStyle:{bgcolor:AMBER,color:WHITE},options:[],callback:()=>!!(self.getLiveState?.()||self.state||{}).warningActive},
    finished:{type:'boolean',name:'Timer is at TIME',defaultStyle:{bgcolor:RED,color:WHITE},options:[],callback:()=>!!(self.getLiveState?.()||self.state||{}).finished},
    queue_enabled:{type:'boolean',name:'Queue is enabled',defaultStyle:{bgcolor:BLUE,color:WHITE},options:[],callback:()=>featureOn(self,'queue')},
    warnings_enabled:{type:'boolean',name:'Warnings are enabled',defaultStyle:{bgcolor:AMBER,color:WHITE},options:[],callback:()=>featureOn(self,'warnings')},
    progress_enabled:{type:'boolean',name:'Progress bar is enabled',defaultStyle:{bgcolor:CYAN,color:WHITE},options:[],callback:()=>featureOn(self,'progress')},
    gradient_enabled:{type:'boolean',name:'Gradient is enabled',defaultStyle:{bgcolor:BLUE,color:WHITE},options:[],callback:()=>featureOn(self,'gradient')},
    minimal_enabled:{type:'boolean',name:'Minimal output is enabled',defaultStyle:{bgcolor:PURPLE,color:WHITE},options:[],callback:()=>featureOn(self,'minimal')},
    chroma_enabled:{type:'boolean',name:'Chroma output is enabled',defaultStyle:{bgcolor:GREEN,color:WHITE},options:[],callback:()=>featureOn(self,'chroma')},
    light_enabled:{type:'boolean',name:'Light output is enabled',defaultStyle:{bgcolor:BLUE,color:WHITE},options:[],callback:()=>featureOn(self,'light')},
    auto_next:{type:'boolean',name:'Queue auto-next is enabled',defaultStyle:{bgcolor:BLUE,color:WHITE},options:[],callback:()=>featureOn(self,'auto_next')},
    autostart:{type:'boolean',name:'Auto start is enabled',defaultStyle:{bgcolor:GREEN,color:WHITE},options:[],callback:()=>featureOn(self,'autostart')},
    count_up:{type:'boolean',name:'Count up mode is enabled',defaultStyle:{bgcolor:PURPLE,color:WHITE},options:[],callback:()=>featureOn(self,'count_up')},

    // Advanced feedbacks let the preset browser use readable static labels while
    // placed buttons show live values/state without relying on a variable resolving
    // during the preset preview.
    display_value:{
      type:'advanced', name:'Live display text', options:[
        {type:'dropdown',id:'mode',label:'Value',default:'time',choices:[
          {id:'time',label:'Timer'},{id:'hh',label:'Hours HH'},{id:'mm',label:'Minutes MM'},{id:'ss',label:'Seconds SS'},
          {id:'status',label:'Status'},{id:'connection',label:'Connection'},{id:'queue',label:'Queue count'},{id:'warning',label:'Warning'}
        ]}
      ],
      callback:(feedback)=>{
        const s=self.getLiveState?.()||self.state||{}, mode=String(feedback.options.mode||'time')
        let text='--'
        if(mode==='time') text=s.displayTime||s.formatted||'00:00'
        else if(mode==='hh') text=s.hours||'00'
        else if(mode==='mm') text=s.minutes||'00'
        else if(mode==='ss') text=s.secondsPart||'00'
        else if(mode==='status') text=s.status||(s.finished?'TIME':s.paused?'PAUSED':s.running?'RUNNING':Number(s.duration||0)>0?'ARMED':'READY')
        else if(mode==='connection') text=self.browserOnline?'CONNECTED':'OFFLINE'
        else if(mode==='queue') text=`QUEUE\n${Number(s.queueLength||0)}`
        else if(mode==='warning') text=s.warningActive?(s.warningLabel||'WARNING'):'WARNING\nOFF'
        return {text, bgcolor: mode==='connection'?(self.browserOnline?GREEN:RED):timerBg(self), color:WHITE}
      }
    },
    pause_resume_state:{
      type:'advanced',name:'Pause / Resume live label',options:[],
      callback:()=>{const s=self.getLiveState?.()||self.state||{};return {text:s.paused?'RESUME':'PAUSE',bgcolor:s.paused?AMBER:GREY,color:WHITE,size:11}}
    },
    feature_state:{
      type:'advanced',name:'Feature toggle state',options:[
        {type:'dropdown',id:'feature',label:'Feature',default:'progress',choices:Object.keys(FEATURE_META).map(id=>({id,label:id.replaceAll('_',' ')}))},
        {type:'textinput',id:'label',label:'Button label',default:'FEATURE'}
      ],
      callback:(feedback)=>{
        const feature=String(feedback.options.feature||''), meta=FEATURE_META[feature]||{color:BLUE}, on=featureOn(self,feature)
        const label=String(feedback.options.label||feature||'FEATURE').toUpperCase()
        return {text:`${label}\n${on?'ON':'OFF'}`,bgcolor:on?meta.color:GREY,color:WHITE,size:10}
      }
    }
  })
}

module.exports.FEATURE_META = FEATURE_META
