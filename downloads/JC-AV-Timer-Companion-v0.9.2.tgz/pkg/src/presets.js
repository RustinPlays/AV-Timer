const { combineRgb } = require('../shim')

const WHITE = combineRgb(255,255,255)
const GREY  = combineRgb(48,55,66)
const GREEN = combineRgb(20,135,68)
const AMBER = combineRgb(170,105,0)
const RED   = combineRgb(170,35,45)
const BLUE  = combineRgb(20,90,160)
const DARK  = combineRgb(24,28,35)
const CYAN  = combineRgb(0,115,145)
const PURPLE= combineRgb(100,60,155)

const TIMES=[['1m',60],['2m',120],['5m',300],['10m',600],['15m',900],['20m',1200],['30m',1800],['45m',2700],['60m',3600]]

const button=(category,name,text,bg,actionId=null,options={},feedbacks=[],size='11',previewText=null)=>({
  type:'button',
  category,
  name,
  style:{text,size:String(size),color:WHITE,bgcolor:bg},
  previewStyle: previewText === null ? undefined : {text:previewText,size:String(size),color:WHITE,bgcolor:bg},
  steps:[{down:actionId?[{actionId,options}]:[],up:[]}],
  feedbacks
})

// IMPORTANT: live text is driven by Companion variables, matching the same
// pattern used by mature timer modules such as Ontime. previewStyle keeps the
// preset browser readable before a connection has supplied values.
const liveVariable=(p,id,name,variable,preview,size='14',feedbacks=[],bg=DARK)=>{
  p[id]=button('JC · Control',name,`$(this:${variable})`,bg,null,{},feedbacks,size,preview)
}

const FEATURE_PRESETS = {
  warnings:  {label:'WARNINGS',  variable:'warnings_state',  feedback:'warnings_enabled',  color:AMBER},
  progress:  {label:'PROGRESS',  variable:'progress_state',  feedback:'progress_enabled',  color:CYAN},
  gradient:  {label:'GRADIENT',  variable:'gradient_state',  feedback:'gradient_enabled',  color:BLUE},
  minimal:   {label:'MINIMAL',   variable:'minimal_state',   feedback:'minimal_enabled',   color:PURPLE},
  chroma:    {label:'CHROMA',    variable:'chroma_state',    feedback:'chroma_enabled',    color:GREEN},
  light:     {label:'LIGHT',     variable:'light_state',     feedback:'light_enabled',     color:BLUE},
  count_up:  {label:'COUNT UP',  variable:'count_up_state',  feedback:'count_up',          color:PURPLE},
  autostart: {label:'AUTO START',variable:'autostart_state', feedback:'autostart',         color:GREEN},
  timer_flash:{label:'FLASH TIMER',variable:'timer_flash_state',feedback:'timer_flash',      color:RED},
}

function addFeatureToggle(p,id,feature){
  const m=FEATURE_PRESETS[feature]
  p[id]=button(
    'JC · Control', `${m.label} Toggle`, `${m.label}\n$(this:${m.variable})`, GREY,
    'feature', {feature},
    [{feedbackId:m.feedback,options:{},style:{bgcolor:m.color,color:WHITE}}],
    '9', m.label
  )
}

module.exports = function(self) {
  const p={}

  // ---- LIVE CLOCK / OUTPUT MODE ----
  liveVariable(p,'clock_live','Live Clock','clock_time','CLOCK','20',[{feedbackId:'clock_mode',options:{},style:{bgcolor:BLUE,color:WHITE}}])
  p.clock_toggle=button('JC · Clock','Clock / Timer Toggle','CLOCK / TIMER',BLUE,'clock_toggle',{},[{feedbackId:'clock_mode',options:{},style:{bgcolor:BLUE,color:WHITE}}],'10')
  p.clock_show=button('JC · Clock','Show Clock','SHOW CLOCK',BLUE,'clock_show',{},[{feedbackId:'clock_mode',options:{},style:{bgcolor:BLUE,color:WHITE}}],'11')
  p.timer_show=button('JC · Clock','Show Timer','SHOW TIMER',GREY,'timer_show',{},[],'11')
  p.clock_24=button('JC · Clock','Clock 24 Hour','CLOCK 24H',CYAN,'clock_format',{format:'24'},[],'10')
  p.clock_12=button('JC · Clock','Clock 12 Hour','CLOCK 12H',CYAN,'clock_format',{format:'12'},[],'10')

  // ---- LIVE / STATUS ----
  // All live displays use variable text directly. Feedbacks only control colour/state.
  const timerFeedbacks=[
    {feedbackId:'running',options:{},style:{bgcolor:GREEN,color:WHITE}},
    {feedbackId:'paused',options:{},style:{bgcolor:AMBER,color:WHITE}},
    {feedbackId:'warning_active',options:{},style:{bgcolor:AMBER,color:WHITE}},
    {feedbackId:'finished',options:{},style:{bgcolor:RED,color:WHITE}},
  ]
  liveVariable(p,'live_time_small','Live Timer · Small','display_time','TIMER','12',timerFeedbacks)
  liveVariable(p,'live_time_medium','Live Timer · Medium','display_time','TIMER','18',timerFeedbacks)
  liveVariable(p,'live_time_large','Live Timer · Large','display_time','TIMER','28',timerFeedbacks)
  liveVariable(p,'hh','Hours HH','hours','HH','26',timerFeedbacks)
  liveVariable(p,'mm','Minutes MM','minutes','MM','26',timerFeedbacks)
  liveVariable(p,'ss','Seconds SS','seconds_part','SS','26',timerFeedbacks)
  liveVariable(p,'status','Timer Status','status','STATUS','12',timerFeedbacks)
  liveVariable(p,'connection','Timer Connection','connection_status','CONNECTED','11',[
    {feedbackId:'browser_online',options:{},style:{bgcolor:GREEN,color:WHITE}}
  ],RED)
  p.queue_count=button('JC · Control','Queue Count','QUEUE\n$(this:queue_length)',DARK,null,{},[
    {feedbackId:'queue_enabled',options:{},style:{bgcolor:BLUE,color:WHITE}}
  ],'11','QUEUE')
  liveVariable(p,'warning_label','Warning Status','warning_display','WARNING','11',[
    {feedbackId:'warning_active',options:{},style:{bgcolor:AMBER,color:WHITE}}
  ])

  // Dedicated feedback/status presets.
  p.running_status=button('JC · Control','Running Feedback','RUNNING',DARK,null,{},[{feedbackId:'running',options:{},style:{bgcolor:GREEN,color:WHITE}}],'10')
  p.paused_status=button('JC · Control','Paused Feedback','PAUSED',DARK,null,{},[{feedbackId:'paused',options:{},style:{bgcolor:AMBER,color:WHITE}}],'10')
  p.time_status=button('JC · Control','TIME Feedback','TIME',DARK,null,{},[{feedbackId:'finished',options:{},style:{bgcolor:RED,color:WHITE}}],'12')
  p.warning_status=button('JC · Control','Warning Feedback','WARNING',DARK,null,{},[{feedbackId:'warning_active',options:{},style:{bgcolor:AMBER,color:WHITE}}],'10')

  // ---- TRANSPORT ----
  p.start=button('JC · Control','Start / Resume','START',GREEN,'start',{},[],'13')
  p.pause_resume=button('JC · Control','Pause / Resume Toggle','$(this:pause_resume_label)',GREY,'toggle',{},[
    {feedbackId:'paused',options:{},style:{bgcolor:AMBER,color:WHITE}},
  ],'11','PAUSE')
  p.reset=button('JC · Control','Reset','RESET',BLUE,'reset',{},[],'11')
  p.stop=button('JC · Control','Stop / Clear','STOP',RED,'stop',{},[],'11')

  // ---- FEATURE TOGGLES ----
  addFeatureToggle(p,'warnings_toggle','warnings')
  addFeatureToggle(p,'progress_toggle','progress')
  addFeatureToggle(p,'gradient_toggle','gradient')
  addFeatureToggle(p,'minimal_toggle','minimal')
  addFeatureToggle(p,'chroma_toggle','chroma')
  addFeatureToggle(p,'light_toggle','light')
  addFeatureToggle(p,'count_up_toggle','count_up')
  addFeatureToggle(p,'autostart_toggle','autostart')
  addFeatureToggle(p,'timer_flash_toggle','timer_flash')
  liveVariable(p,'queue_name','Queue Name','queue_name','QUEUE NAME','9',[])
  liveVariable(p,'current_item','Current Queue Item','current_item','CURRENT','9',[])
  liveVariable(p,'next_item','Next Queue Item','next_item','NEXT ITEM','9',[])
  liveVariable(p,'network_viewers','Network Viewers','network_viewers','VIEWERS','11',[])
  p.message_show=button('JC · Control','Presenter Message: Wrap Up','WRAP UP',AMBER,'presenter_message',{text:'PLEASE WRAP UP',show:true,flash:false,mode:'banner'},[{feedbackId:'message_visible',options:{},style:{bgcolor:AMBER,color:WHITE}}],'9')
  p.message_hide=button('JC · Control','Presenter Message: Hide','HIDE\nMESSAGE',GREY,'presenter_message_hide',{},[],'9')
  p.message_clear=button('JC · Control','Presenter Message: Clear','CLEAR\nMESSAGE',RED,'presenter_message_clear',{},[],'9')

  const sizes=[['Small',0.75],['Medium',1],['Large',1.25],['XL',1.5],['XXL',1.8]]
  for(const [label,scale] of sizes){
    p[`size_${String(scale).replace('.','_')}`]=button('JC · Control',`Timer Size ${label}`,`SIZE\n${label.toUpperCase()}`,BLUE,'output_size',{scale},[],'9')
  }

  // ---- QUICK TIME PRESETS ----
  for(const [label,seconds] of TIMES){
    p[`add_${seconds}`]=button('JC · Add',`Add ${label}`,`+${label}`,GREEN,'add_preset',{seconds},[],'14')
    p[`sub_${seconds}`]=button('JC · Remove',`Remove ${label}`,`−${label}`,RED,'subtract_preset',{seconds},[],'14')
    p[`start_${seconds}`]=button('JC · Start',`Start ${label}`,`START\n${label}`,GREEN,'start_preset',{seconds},[],'10')
    p[`set_${seconds}`]=button('JC · Set',`Set ${label}`,`SET\n${label}`,GREY,'set_preset',{seconds},[],'10')
  }

  // ---- QUEUE ----
  p.queue_toggle=button('JC · Queue','Queue Toggle','QUEUE\n$(this:queue_state)',GREY,'feature',{feature:'queue'},[
    {feedbackId:'queue_enabled',options:{},style:{bgcolor:BLUE,color:WHITE}}
  ],'9','QUEUE')
  p.auto_next_toggle=button('JC · Queue','Auto Next Toggle','AUTO NEXT\n$(this:auto_next_state)',GREY,'feature',{feature:'auto_next'},[
    {feedbackId:'auto_next',options:{},style:{bgcolor:BLUE,color:WHITE}}
  ],'8','AUTO NEXT')
  p.queue_start=button('JC · Queue','Start Queue','START\nQUEUE',GREEN,'queue_start',{},[],'9')
  p.queue_next=button('JC · Queue','Next Queue Timer','NEXT',BLUE,'next',{},[],'11')
  p.queue_remove_last=button('JC · Queue','Remove Last Queue Timer','REMOVE\nLAST',AMBER,'queue_remove_last',{},[],'9')
  p.queue_clear=button('JC · Queue','Clear Queue','CLEAR\nQUEUE',RED,'queue_clear',{},[],'9')

  for(const [label,seconds] of TIMES){
    p[`queue_add_${seconds}`]=button('JC · Queue Add',`Queue + ${label}`,`QUEUE +\n${label}`,GREEN,'queue_add_preset',{seconds},[],'9')
  }

  self.setPresetDefinitions(p)
}
