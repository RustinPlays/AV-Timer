# JC - AV Timer

1. Add the **JC - AV Timer** connection.
2. Leave the local timer API port at **3210** unless that port is already in use.
3. Open JC AV Timer on the same laptop, either from GitHub Pages or the offline files.
4. Wait for the timer's top bar to show **Companion connected**.
5. Search **JC** in Companion Presets.

Preset groups are **JC · Control**, **JC · Add**, **JC · Remove**, **JC · Start**, **JC · Set**, **JC · Queue**, and **JC · Queue Add**.

Live TIMER / HH / MM / SS displays and Pause / Resume feedback are driven by Companion itself from the timer's wall-clock anchors, so they continue updating while the browser is unfocused.

## Clock mode

Use Show Clock, Show Timer or Clock / Timer Toggle from the presets. Change 12/24 hour format with Clock 12H / Clock 24H. The live clock variable is `$(this:clock_time)`. Keep the timer website open on the same computer, with the Companion API port matched.
