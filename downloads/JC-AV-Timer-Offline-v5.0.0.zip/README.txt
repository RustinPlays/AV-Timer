JC AV Timer v5.0.0 Offline

1. Extract this ZIP to a normal folder.
2. Double-click "JC AV Timer.html".
3. Timer, queue, presenter messages, warnings, appearance, PiP and the external output window work locally.
4. For Bitfocus Companion, import downloads/JC-AV-Timer-Companion-0.8.0.tgz and add the JC - AV Timer connection. Default local API port: 3210.
5. Remote Viewer can still be used from this offline copy when internet is available. Viewers go to relay.justincreative.tech.

Do not run the HTML directly from inside the ZIP. Extract it first.
