# JC - AV Timer v0.8.0

1. Import this package in Bitfocus Companion as a custom module/package.
2. Add **JC - AV Timer** as a connection.
3. Leave the local API port at **3210** unless you deliberately changed it in the timer.
4. Keep Companion and the JC AV Timer operator open on the same computer.
5. Wait for **Companion connected** in the timer top bar.

Presets include Start/Pause, Reset, Stop, Next Cue, timer presets, add/remove time, queue feedback, presenter messages, Flash Timer, Flash Message, warning/display toggles and live timer/cue/message/viewer feedback.

The module calculates the live timer from the operator's wall-clock anchors, so the displayed time continues updating even while the browser is unfocused.
