const { combineRgb } = require('../shim')

const WHITE=combineRgb(255,255,255)
const GREEN=combineRgb(20,150,75)
const AMBER=combineRgb(190,120,0)
const RED=combineRgb(190,30,40)
const BLUE=combineRgb(20,90,160)
const CYAN=combineRgb(0,120,150)
const PURPLE=combineRgb(105,65,160)

const FEATURE_META = {
  queue:      {state:'queueEnabled',     color:BLUE},
  warnings:   {state:'warningsEnabled',  color:AMBER, defaultOn:true},
  progress:   {state:'progressEnabled',  color:CYAN},
  gradient:   {state:'gradientEnabled',  color:BLUE, defaultOn:true},
  minimal:    {state:'minimalEnabled',   color:PURPLE},
  chroma:     {state:'chromaEnabled',    color:GREEN},
  light:      {state:'lightEnabled',     color:BLUE},
  timer_flash:{state:'timerFlash',        color:RED},
  auto_next:  {state:'autoNext',         color:BLUE},
  autostart:  {state:'autostart',        color:GREEN, defaultOn:true},
  count_up:   {state:'countUp',          color:PURPLE}
}

function live(self){ return self.getLiveState?.() || self.state || {} }
function featureOn(self, feature){
  const meta=FEATURE_META[feature]
  if(!meta) return false
  const v=live(self)?.[meta.state]
  return v === undefined ? !!meta.defaultOn : !!v
}

module.exports = function(self) {
  self.setFeedbackDefinitions({
    clock_mode:{type:'boolean',name:'Clock is visible on output',defaultStyle:{bgcolor:BLUE,color:WHITE},options:[],callback:()=>live(self).displayMode==='clock'},
    bridge_online:{type:'boolean',name:'Timer browser connected (legacy id)',defaultStyle:{bgcolor:BLUE,color:WHITE},options:[],callback:()=>!!self.browserOnline},
    browser_online:{type:'boolean',name:'Timer browser connected',defaultStyle:{bgcolor:GREEN,color:WHITE},options:[],callback:()=>!!self.browserOnline},

    running:{type:'boolean',name:'Timer is running',defaultStyle:{bgcolor:GREEN,color:WHITE},options:[],callback:()=>{const s=live(self);return !!s.running&&!s.paused}},
    paused:{type:'boolean',name:'Timer is paused',defaultStyle:{bgcolor:AMBER,color:WHITE},options:[],callback:()=>!!live(self).paused},
    warning_active:{type:'boolean',name:'Custom warning is active',defaultStyle:{bgcolor:AMBER,color:WHITE},options:[],callback:()=>!!live(self).warningActive},
    finished:{type:'boolean',name:'Timer is at TIME',defaultStyle:{bgcolor:RED,color:WHITE},options:[],callback:()=>!!live(self).finished},

    queue_enabled:{type:'boolean',name:'Queue is enabled',defaultStyle:{bgcolor:BLUE,color:WHITE},options:[],callback:()=>featureOn(self,'queue')},
    warnings_enabled:{type:'boolean',name:'Warnings are enabled',defaultStyle:{bgcolor:AMBER,color:WHITE},options:[],callback:()=>featureOn(self,'warnings')},
    progress_enabled:{type:'boolean',name:'Progress bar is enabled',defaultStyle:{bgcolor:CYAN,color:WHITE},options:[],callback:()=>featureOn(self,'progress')},
    gradient_enabled:{type:'boolean',name:'Gradient is enabled',defaultStyle:{bgcolor:BLUE,color:WHITE},options:[],callback:()=>featureOn(self,'gradient')},
    minimal_enabled:{type:'boolean',name:'Minimal output is enabled',defaultStyle:{bgcolor:PURPLE,color:WHITE},options:[],callback:()=>featureOn(self,'minimal')},
    chroma_enabled:{type:'boolean',name:'Chroma output is enabled',defaultStyle:{bgcolor:GREEN,color:WHITE},options:[],callback:()=>featureOn(self,'chroma')},
    light_enabled:{type:'boolean',name:'Light output is enabled',defaultStyle:{bgcolor:BLUE,color:WHITE},options:[],callback:()=>featureOn(self,'light')},
    auto_next:{type:'boolean',name:'Queue auto-next is enabled',defaultStyle:{bgcolor:BLUE,color:WHITE},options:[],callback:()=>featureOn(self,'auto_next')},
    autostart:{type:'boolean',name:'Auto start is enabled',defaultStyle:{bgcolor:GREEN,color:WHITE},options:[],callback:()=>featureOn(self,'autostart')},
    count_up:{type:'boolean',name:'Count up mode is enabled',defaultStyle:{bgcolor:PURPLE,color:WHITE},options:[],callback:()=>featureOn(self,'count_up')},
    timer_flash:{type:'boolean',name:'Timer flashing is enabled',defaultStyle:{bgcolor:RED,color:WHITE},options:[],callback:()=>featureOn(self,'timer_flash')},
    message_visible:{type:'boolean',name:'Presenter message is visible',defaultStyle:{bgcolor:AMBER,color:WHITE},options:[],callback:()=>!!(live(self).display?.presenterMessage?.visible || live(self).presenterMessage?.visible)},

    // Compatibility feedbacks for buttons created with v0.5-v0.7. New v0.8
    // presets use Companion variables for live text, but keeping these IDs means
    // older placed buttons do not immediately break after the module upgrade.
    display_value:{
      type:'advanced', name:'Live display text (legacy compatibility)', options:[
        {type:'dropdown',id:'mode',label:'Value',default:'time',choices:[
          {id:'time',label:'Timer'},{id:'dd',label:'Days DD'},{id:'hh',label:'Total Hours HH'},{id:'hh_day',label:'Hours in Day'},{id:'mm',label:'Minutes MM'},{id:'ss',label:'Seconds SS'},{id:'total_mm',label:'Total Minutes'},{id:'total_ss',label:'Total Seconds'},
          {id:'status',label:'Status'},{id:'connection',label:'Connection'},{id:'queue',label:'Queue count'},{id:'warning',label:'Warning'}
        ]}
      ],
      callback:(feedback)=>{
        const s=live(self), mode=String(feedback.options.mode||'time')
        let text='--'
        if(mode==='time') text=s.displayTime||s.formatted||'00:00'
        else if(mode==='dd') text=s.days||'00'
        else if(mode==='hh') text=s.hours||'00'
        else if(mode==='hh_day') text=s.hoursInDay||'00'
        else if(mode==='mm') text=s.minutes||'00'
        else if(mode==='ss') text=s.secondsPart||'00'
        else if(mode==='total_mm') text=s.totalMinutes||'0'
        else if(mode==='total_ss') text=s.totalSeconds||'0'
        else if(mode==='status') text=s.status||'READY'
        else if(mode==='connection') text=self.browserOnline?'CONNECTED':'OFFLINE'
        else if(mode==='queue') text=`QUEUE\n${Number(s.queueLength||0)}`
        else if(mode==='warning') text=s.warningActive?(s.warningLabel||'WARNING'):'WARNING\nOFF'
        const bgcolor=s.finished?RED:s.warningActive||s.paused?AMBER:s.running?GREEN:BLUE
        return {text,bgcolor:mode==='connection'?(self.browserOnline?GREEN:RED):bgcolor,color:WHITE}
      }
    },
    pause_resume_state:{
      type:'advanced',name:'Pause / Resume live label (legacy compatibility)',options:[],
      callback:()=>{const s=live(self);return {text:s.paused?'RESUME':'PAUSE',bgcolor:s.paused?AMBER:BLUE,color:WHITE,size:11}}
    },
    feature_state:{
      type:'advanced',name:'Feature toggle state (legacy compatibility)',options:[
        {type:'dropdown',id:'feature',label:'Feature',default:'progress',choices:Object.keys(FEATURE_META).map(id=>({id,label:id.replaceAll('_',' ')}))},
        {type:'textinput',id:'label',label:'Button label',default:'FEATURE'}
      ],
      callback:(feedback)=>{
        const feature=String(feedback.options.feature||''), meta=FEATURE_META[feature]||{color:BLUE}, on=featureOn(self,feature)
        const label=String(feedback.options.label||feature||'FEATURE').toUpperCase()
        return {text:`${label}\n${on?'ON':'OFF'}`,bgcolor:on?meta.color:BLUE,color:WHITE,size:10}
      }
    },
  })
}

module.exports.FEATURE_META = FEATURE_META
