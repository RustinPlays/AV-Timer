const { combineRgb } = require('../shim')
const C = {
  white:combineRgb(255,255,255), green:combineRgb(18,132,72),
  red:combineRgb(178,38,52), amber:combineRgb(166,105,12),
  blue:combineRgb(27,83,148), cyan:combineRgb(23,108,140),
  purple:combineRgb(95,71,147), grey:combineRgb(54,63,76), dark:combineRgb(25,32,42)
}
const GROUP={
  playback:'JC 01 · Start / Pause / Stop',set:'JC 02 · Set Time',
  add:'JC 03 · Add Time (+)',minus:'JC 04 · Remove Time (-)',
  live:'JC 05 · Live Timer',clock:'JC 06 · Clock',
  queue:'JC 07 · Cue Queue',queueAdd:'JC 08 · Add To Queue',
  messages:'JC 09 · Messages',appearance:'JC 10 · Appearance',
  status:'JC 11 · Feedbacks / Status'
}
const TIMES=[['1m',60],['2m',120],['3m',180],['5m',300],['10m',600],['15m',900],['20m',1200],['30m',1800],['45m',2700],['60m',3600]]
const ref=id=>`$(jc-av-timer:${id})`
const fb=(feedbackId,bgcolor)=>({feedbackId,options:{},style:{bgcolor,color:C.white}})
const timerFeedbacks=()=>[
  fb('running',C.green), fb('paused',C.amber),
  fb('warning_active',C.amber),fb('finished',C.red)
]
function button(category,name,text,bg,actionId=null,options={},feedbacks=[],size=11,preview=null) {
  const s=String(size)
  return {type:'button',category,name,style:{text,size:s,color:C.white,bgcolor:bg},
    ...(preview==null?{}:{previewStyle:{text:preview,size:s,color:C.white,bgcolor:bg}}),
    steps:[{down:actionId?[{actionId,options}]:[],up:[]}],feedbacks}
}
function live(p,key,name,variable,preview,size=13,feedbacks=timerFeedbacks(),bg=C.dark){
  p[key]=button(GROUP.live,name,ref(variable),bg,null,{},feedbacks,size,preview)
}
function toggle(p,key,name,label,variable,feedbackId,color= C.blue,feature=null){
  p[key]=button(GROUP.appearance,name,`${label}\n${ref(variable)}`,C.grey,'feature',
    {feature:feature||key.replace(/_toggle$/,'')},[fb(feedbackId,color)],9,label)
}
module.exports=function registerPresets(self){
  const p={}
  // Playback; preserve established preset ids to avoid breaking custom layouts.
  p.start=button(GROUP.playback,'Start / Resume','START',C.green,'start',{},[],11)
  p.pause_resume=button(GROUP.playback,'Pause / Resume','PAUSE / RESUME',C.grey,'toggle',{},[fb('paused',C.amber),fb('running',C.green)],10)
  p.reset=button(GROUP.playback,'Reset Timer','RESET',C.blue,'reset',{},[],11)
  p.stop=button(GROUP.playback,'Stop / Clear','STOP',C.red,'stop',{},[],11)

  // Full timer presets, together by operation.
  for (const [label,seconds] of TIMES) {
    p[`set_${seconds}`]=button(GROUP.set,`Set ${label}`,`SET\n${label}`,C.blue,'set_preset',{seconds},[],11)
  }
  for (const [label,seconds] of TIMES) {
    p[`add_${seconds}`]=button(GROUP.add,`Add ${label}`,`+${label}`,C.green,'add_preset',{seconds},[],12)
  }
  for (const [label,seconds] of TIMES) {
    p[`sub_${seconds}`]=button(GROUP.minus,`Remove ${label}`,`−${label}`,C.red,'subtract_preset',{seconds},[],12)
  }
  for (const [label,seconds] of TIMES) {
    p[`start_${seconds}`]=button(GROUP.playback,`Start ${label}`,`START\n${label}`,C.green,'start_preset',{seconds},[],10)
  }

  // Direct live variables: hours are total hours (can exceed 24); days and
  // hours_in_day are also available independently for multi-day displays.
  live(p,'live_time_small','Live timer · Compact','display_time','00:00:00',10)
  live(p,'live_time_medium','Live timer · Standard','display_time','00:00:00',14)
  live(p,'live_time_large','Live timer · Large','display_time','00:00:00',18)
  live(p,'dd','Days (DD)','days','DD',14)
  live(p,'hh','Total hours (HH)','hours','HH',14)
  live(p,'hh_day','Hours in day (00–23)','hours_in_day','HH',14)
  live(p,'mm','Minutes (MM)','minutes','MM',14)
  live(p,'ss','Seconds (SS)','seconds_part','SS',14)
  live(p,'total_hours','Total hours','total_hours','HRS',13)
  live(p,'total_minutes','Total minutes','total_minutes','MINS',13)
  live(p,'total_seconds','Total seconds','total_seconds','SECS',13)
  live(p,'status','Live timer status','status','READY',11)
  live(p,'connection','Timer connection','connection_status','CONNECTED',9,[fb('browser_online',C.green)],C.red)
  live(p,'warning_label','Warning text','warning_display','WARNING',10,[fb('warning_active',C.amber)])

  // Clock mode and wall-clock variables, including seconds.
  p.clock_live=button(GROUP.clock,'Live wall clock',ref('clock_time'),C.dark,null,{},[fb('clock_mode',C.blue)],13,'12:34:56')
  p.clock_live_24=button(GROUP.clock,'Live 24-hour clock',ref('clock_time_24'),C.dark,null,{},[],13,'13:34:56')
  p.clock_live_12=button(GROUP.clock,'Live 12-hour clock',ref('clock_time_12'),C.dark,null,{},[],12,'01:34:56 PM')
  p.clock_toggle=button(GROUP.clock,'Toggle Clock / Timer','CLOCK / TIMER',C.blue,'clock_toggle',{},[fb('clock_mode',C.cyan)],10)
  p.clock_show=button(GROUP.clock,'Show Clock','SHOW CLOCK',C.blue,'clock_show',{},[fb('clock_mode',C.cyan)],10)
  p.timer_show=button(GROUP.clock,'Show Timer','SHOW TIMER',C.grey,'timer_show',{},[],10)
  p.clock_24=button(GROUP.clock,'24 Hour Clock','24H CLOCK',C.cyan,'clock_format',{format:'24'},[],10)
  p.clock_12=button(GROUP.clock,'12 Hour Clock','12H CLOCK',C.cyan,'clock_format',{format:'12'},[],10)

  // Queue grouped separately from queue time add buttons.
  p.queue_toggle=button(GROUP.queue,'Queue enabled',`QUEUE\n${ref('queue_state')}`,C.grey,'feature',{feature:'queue'},[fb('queue_enabled',C.blue)],9,'QUEUE')
  p.auto_next_toggle=button(GROUP.queue,'Queue auto next',`AUTO NEXT\n${ref('auto_next_state')}`,C.grey,'feature',{feature:'auto_next'},[fb('auto_next',C.blue)],9,'AUTO NEXT')
  p.queue_start=button(GROUP.queue,'Start queue','START QUEUE',C.green,'queue_start',{},[],10)
  p.queue_next=button(GROUP.queue,'Next cue','NEXT CUE',C.blue,'next',{},[],11)
  p.queue_remove_last=button(GROUP.queue,'Remove last cue','REMOVE LAST',C.amber,'queue_remove_last',{},[],9)
  p.queue_clear=button(GROUP.queue,'Clear cue queue','CLEAR QUEUE',C.red,'queue_clear',{},[],9)
  p.queue_count=button(GROUP.queue,'Queued count',`QUEUE\n${ref('queue_length')}`,C.dark,null,{},[fb('queue_enabled',C.blue)],12,'QUEUE')
  p.queue_name=button(GROUP.queue,'Queue name',ref('queue_name'),C.dark,null,{},[],10,'QUEUE NAME')
  p.current_item=button(GROUP.queue,'Current cue',ref('current_item'),C.dark,null,{},[],9,'CURRENT CUE')
  p.next_item=button(GROUP.queue,'Next cue label',ref('next_item'),C.dark,null,{},[],9,'NEXT CUE')
  for (const [label,seconds] of TIMES) {
    p[`queue_add_${seconds}`]=button(GROUP.queueAdd,`Queue + ${label}`,`QUEUE +\n${label}`,C.green,'queue_add_preset',{seconds},[],9)
  }

  p.message_show=button(GROUP.messages,'Show Wrap Up','WRAP UP',C.amber,'presenter_message',
    {text:'PLEASE WRAP UP',show:true,flash:false,mode:'banner'},[fb('message_visible',C.amber)],10)
  p.message_hide=button(GROUP.messages,'Hide message','HIDE MESSAGE',C.grey,'presenter_message_hide',{},[],9)
  p.message_clear=button(GROUP.messages,'Clear message','CLEAR MESSAGE',C.red,'presenter_message_clear',{},[],9)

  const features=[
    ['warnings_toggle','Warning toggled','WARNINGS','warnings_state','warnings_enabled',C.amber,'warnings'],
    ['progress_toggle','Progress bar toggled','PROGRESS','progress_state','progress_enabled',C.cyan,'progress'],
    ['gradient_toggle','Gradient toggled','GRADIENT','gradient_state','gradient_enabled',C.blue,'gradient'],
    ['minimal_toggle','Minimal toggled','MINIMAL','minimal_state','minimal_enabled',C.purple,'minimal'],
    ['chroma_toggle','Chroma toggled','CHROMA','chroma_state','chroma_enabled',C.green,'chroma'],
    ['light_toggle','Light output toggled','LIGHT','light_state','light_enabled',C.blue,'light'],
    ['count_up_toggle','Count-up toggled','COUNT UP','count_up_state','count_up',C.purple,'count_up'],
    ['autostart_toggle','Auto-start toggled','AUTO START','autostart_state','autostart',C.green,'autostart'],
    ['timer_flash_toggle','Timer flash toggled','FLASH TIMER','timer_flash_state','timer_flash',C.red,'timer_flash'],
  ]
  for(const [id,name,label,variable,feedback,color,feature] of features){toggle(p,id,name,label,variable,feedback,color,feature)}
  for(const [label,scale] of [['Small',0.75],['Medium',1],['Large',1.25],['XL',1.5],['XXL',1.8]]){
    p[`size_${String(scale).replace('.','_')}`]=button(GROUP.appearance,`Timer size: ${label}`,`SIZE ${label.toUpperCase()}`,C.blue,'output_size',{scale},[],9)
  }

  p.running_status=button(GROUP.status,'Running feedback','RUNNING',C.dark,null,{},[fb('running',C.green)],10)
  p.paused_status=button(GROUP.status,'Paused feedback','PAUSED',C.dark,null,{},[fb('paused',C.amber)],10)
  p.time_status=button(GROUP.status,'Time reached feedback','TIME',C.dark,null,{},[fb('finished',C.red)],10)
  p.warning_status=button(GROUP.status,'Warning active','WARNING',C.dark,null,{},[fb('warning_active',C.amber)],10)
  p.network_viewers=button(GROUP.status,'LAN viewers',ref('network_viewers'),C.dark,null,{},[],11,'VIEWERS')
  self.setPresetDefinitions(p)
}
