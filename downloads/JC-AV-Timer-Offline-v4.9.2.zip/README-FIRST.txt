JC AV TIMER — OFFLINE PACKAGE v4.9.2

FASTEST WAY TO OPEN
-------------------
Double-click:  Open AV Timer App.html

That file is self-contained. It includes the timer styling, scripts, logo, output view,
and the Companion module download, so it can be opened even directly from the ZIP.

ONLINE SHORTCUT
---------------
JC AV Timer - Online.url opens the hosted GitHub Pages version when internet is available.

DESKTOP SHORTCUT
----------------
After extracting, right-click "Open AV Timer App.html" -> Show more options -> Send to -> Desktop (create shortcut).
This uses Windows' normal shortcut system and does not require an EXE or installer.

COMPANION
---------
Use the Companion Module button inside the timer, or the bundled TGZ in downloads/.
