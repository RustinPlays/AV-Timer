JC AV TIMER — OFFLINE VERSION v4.8

HOW TO OPEN
1. Extract this ZIP to a normal folder.
2. Double-click "JC AV Timer.html".
3. Your normal browser opens the timer locally. Internet is not required for the timer itself.

COMPANION
The ready-to-import module is included at:
downloads\JC-AV-Timer-Companion-0.6.0.tgz

In Bitfocus Companion:
Modules -> Import custom module/package -> select that TGZ
Then add a connection and search for "JC - AV Timer".
Leave the local timer API port at 3210 unless you need another port.

WINDOWS SECURITY
This offline package intentionally contains no EXE, MSI, CMD, BAT or PowerShell launcher.
There is therefore no unsigned executable that needs the Windows "Unblock" step.

NOTE
The timer is wall-clock based. Minimising the browser, switching apps or leaving the tab
unfocused does not pause or slow the timer. When the browser gets CPU time again it renders
the correct current time from its clock anchor.
